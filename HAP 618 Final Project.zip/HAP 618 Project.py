#!/usr/bin/env python
# coding: utf-8

# In[24]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier


# In[25]:


data = pd.read_csv("C:/Users/rahul/OneDrive/Desktop/cleveland.csv")


# In[26]:


data.columns = ['age', 'sex', 'cp', 'trestbps', 'chol',
              'fbs', 'restecg', 'thalach', 'exang', 
              'oldpeak', 'slope', 'ca', 'thal', 'target']


# In[ ]:





# In[27]:


data.isnull().sum()


# In[28]:


data['target'] = data.target.map({0: 0, 1: 1, 2: 1, 3: 1, 4: 1})
data['thal'] = data.thal.fillna(data.thal.mean())
data['ca'] = data.ca.fillna(data.ca.mean())


# In[29]:


data.isnull().sum()


# In[30]:


data.head()


# In[31]:


pd.crosstab(data.age, data.target).plot(kind = 'line', figsize = (15,5))
plt.title('Distribution of Heart Disease based on Age')
plt.xlabel('Age')
plt.ylabel('Distribution')
plt.show()


# In[32]:


sns.countplot(x = 'sex', data = data, palette = 'inferno_r')
plt.xlabel('Sex ( 0 = Female , 1 = Male )')
plt.show()


# In[33]:


# Heart Disease frequency based on Sex.
pd.crosstab(data.sex, data.target).plot(kind = 'bar', figsize = (15,5))
plt.title("Frequency of Heart Disease based on Sex")
plt.xlabel('Sex ( 0 = Female , 1 = Male )')
plt.xticks(rotation = 0)
plt.legend(['Without_Disease' , 'With_Disease'])
plt.ylabel('Frequency')
plt.show()


# In[34]:


#Converting categorical variables to dummy variables in cp, thal and slope.

cp_dummies = pd.get_dummies(data['cp'], prefix = 'cp')
thal_dummies = pd.get_dummies(data['thal'], prefix = 'thal')
slope_dummies = pd.get_dummies(data['slope'], prefix = 'slope')


# In[35]:


changed_variables = [data, cp_dummies, thal_dummies, slope_dummies]
data = pd.concat(changed_variables, axis = 1)
data.head()


# In[36]:


# Dropping the original columns

data = data.drop(columns = ['cp', 'thal', 'slope'])
data.head()


# In[37]:


# Preparing data for Normalization

x_norm = data.drop(['target'], axis = 1)
y = data.target.values


# In[38]:


# Normalization
x = (x_norm - np.min(x_norm)) / (np.max(x_norm) - np.min(x_norm)).values


# In[39]:


# Splitting the data
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size = 0.2, random_state = 0)

Model_scores = {}


# In[40]:


# Logistic Regression.

log_reg = LogisticRegression()
log_reg.fit(x_train, y_train)

LR_Model_Accuracy = log_reg.score(x_test, y_test) * 100
print('Logistic Regression model accuracy is {:.2f}%'.format(LR_Model_Accuracy))
Model_scores['Logistic Regression'] = LR_Model_Accuracy


# In[41]:


# KNN
# Finding the best K value

KNN_Scores = []

for neighbors in range(1,25):
    knn = KNeighborsClassifier(n_neighbors = neighbors)
    knn.fit(x_train, y_train)
    KNN_Scores.append(knn.score(x_test, y_test))
    
Max_KnnScore = max(KNN_Scores)*100
print('The Maximum score for KNN model is {:.2f}%'.format(Max_KnnScore))
Model_scores['KNN'] = Max_KnnScore


# In[42]:


# Decision Tree.
decision_tree = DecisionTreeClassifier() 
decision_tree.fit(x_train, y_train)

D_score = decision_tree.score(x_test, y_test)*100
print('Decision Tree model accuracy is {:.2f}%'.format(D_score))
Model_scores['Decision Tree'] = D_score


# In[43]:


# Analysis of model scores.
colors = ['green', 'orange', 'magenta']
sns.set_style('whitegrid')
plt.figure(figsize = (8,5))
plt.xlabel('Models')
plt.ylabel('Accuracy %')
plt.yticks(np.arange(0,100,10))
sns.barplot(x = list(Model_scores.keys()), y = list(Model_scores.values()), palette = colors)
plt.show()


# In[44]:


print(Model_scores)


# In[ ]:





# In[ ]:




